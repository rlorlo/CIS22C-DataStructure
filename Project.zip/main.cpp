//Main.cpp
//Created By Richard Orlowski

#include "DataBase.h"
#include "menuPropmt.h"

int main()
{
	DataBase Stars;
	Menu run;



}
